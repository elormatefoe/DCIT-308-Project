# Pharmaqcy-Management-Software-with-J2SE
This project is still under development
