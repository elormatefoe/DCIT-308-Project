package pharmacy;
public class Pharmacy {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
