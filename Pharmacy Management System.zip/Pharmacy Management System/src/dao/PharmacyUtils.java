
package dao;

/**
 *
 * @author Daniel
 */
public class PharmacyUtils {
    public static String billPath = "E:\\";
}
