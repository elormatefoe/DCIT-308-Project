

/**
 *
 * @author oduro
 */
class Paragraph {

    Paragraph(String thank_You_Please_Visit_Again_) {
    }
    
}
